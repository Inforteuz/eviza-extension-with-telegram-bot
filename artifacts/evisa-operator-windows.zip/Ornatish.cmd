@echo off
call "%~dp0windows\Install.cmd"
